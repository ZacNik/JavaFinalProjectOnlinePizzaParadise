package com.acme.mvcjpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcjpademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
